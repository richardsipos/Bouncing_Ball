In order to run the following python game, please commit to the following instructions: 
    Prerequisites:
        - Python installed in your development environment.
        - The following libraries installed on your development environment.
            - cv2
            - numpy
            - easygui
            - time
    Execute the program:
        - In order to execute the program type python homework.py in your terminal.

Note:
    Alongside the readme.txt and homework.py there is demo incorporated in the .zip file.
